<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <link href="<?php echo e(URL::to('/css/chat.css')); ?>" rel="stylesheet" />

</head>

<body class="bg-gray-200 flex justify-center items-center h-screen">
    <?php if(Route::has('login')): ?>
    <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
        <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(url('/dashboard')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Dashboard</a>
        <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
            <?php echo e(__('Profile')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>

            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                <?php echo e(__('Log Out')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
        </form>
        <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>

        <?php if(Route::has('register')): ?>
        <a href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <div class="bg-white rounded-lg shadow-md p-4 w-96">
        <h1 class="text-xl font-semibold mb-4">Chat Lists</h1>
        <div id="chat-lists" class="mb-4">

            <?php if(!$chatlistUserData->isEmpty()): ?>
            <?php $__currentLoopData = $chatlistUserData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $url = 'chat/' . $chatlist->id ?>
            <p><a href="<?php echo e(URL::to($url)); ?>"><?php echo e($chatlist->name); ?></a>
                <?php if(isset($unreadMessagesCount[$chatlist->id]) && $unreadMessagesCount[$chatlist->id] > 0): ?>

                <span class="text-xs text-red-500 unread-count" data-chat="<?php echo e($chatlist->id); ?>"><?php echo e($unreadMessagesCount[$chatlist->id]); ?></span>
                <?php endif; ?>
            </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <h3 class="text-xs font-semibold mb-4">You Can Chat with Our Users</h3>
            <?php $__currentLoopData = $getUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $url = 'chat/' . $user->id ?>
            <p><a href="<?php echo e(URL::to($url)); ?>"><?php echo e($user->name); ?></a></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>

    </div>
    <div class="container d-flex justify-content-center">
        <div><span>Logged by <?php echo e(auth()->user()->name); ?></span></div>
        <div class="card mt-5">
            <div class="d-flex flex-row justify-content-between p-3 adiv text-white">
                <i class="fas fa-chevron-left"></i>
                <span class="pb-3">Live chat <?php echo (!empty($recipient) ? "with " . $recipient->name : "") ?></span>
                <i class="fas fa-times"></i>
            </div>
            <div id="chat_area">
                <?php if((!empty($allMessages)) && isset($allMessages)): ?>
                <?php $__currentLoopData = $allMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($message->sender == auth()->user()->id ): ?>
                <div class="d-flex flex-row p-3">

                    <div class="bg-white mr-2 p-3"><span class="text-muted sendChat"><?php echo e($message->message); ?>

                        </span> <?php if($message->read_status == '0'): ?>
                        <i class="fas fa-check"></i> <!-- Double tick mark indicating delivered -->
                        <?php elseif($message->read_status == '1'): ?>
                        <i class="fas fa-check-double seen"></i> <!-- Double tick mark indicating seen -->
                        <?php endif; ?>
                    </div>
                    <img src="https://img.icons8.com/color/48/000000/circled-user-male-skin-type-7.png" width="30" height="30">


                </div>
                <?php else: ?>
                <div class="d-flex flex-row p-3">

                    <img src="https://img.icons8.com/color/48/000000/circled-user-female-skin-type-7.png" width="30" height="30">

                    <div class="chat ml-2 p-3"><?php echo e($message->message); ?>


                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>

            <div class="form-group px-3">
                <input type="text" class="form-control" id="message-input" placeholder="Type your message" />
            </div>
            <?php if((!empty($recipient)) && isset($recipient)): ?>
            <?php $disable = ""; ?>
            <input type="hidden" id="recipientId" value="<?php echo e($recipient->id); ?>">
            <?php else: ?>

            <?php $disable = "disabled"; ?>
            <?php endif; ?>

            <button class="btn btn-success my-2" id="send-message" <?php echo e($disable); ?>>Send</button>
        </div>
    </div>

    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>


    <script>
        Pusher.logToConsole = true;

        var pusher = new Pusher('8299b0b5e669284d1e9b', {
            cluster: 'mt1',
            encrypted: true,
        });

        var recipientChannel = 'private-chat.<?php echo e(auth()->user()->id); ?>';
       
        const channelName = "private-chat";
        clientSendChannel = pusher.subscribe(`${channelName}.<?php echo e($recipient->id ?? ""); ?>`);
        clientListenChannel = pusher.subscribe(`${channelName}.<?php echo e(auth()->user()->id); ?>`);
        // console.log(clientSendChannel);
        // Subscribe to presence channel
        const presenceChannel = pusher.subscribe('presence-online-users');
        // console.log(presenceChannel);
        // Bind to presence events
        presenceChannel.bind('pusher:subscription_succeeded', (members) => {
        members.each((member) => {
            console.log(`${member.id} is online.`);
            function getUserStatus(id){
                if(id === member.id){
                    console.log("message sent");
                }

            }
        });
        });

      console.log(member);

        presenceChannel.bind('pusher:member_added', (member) => {

        console.log(`${member.id} is online.`);
        });

        presenceChannel.bind('pusher:member_removed', (member) => {
        console.log(`${member.id} is offline.`);
        });

        clientListenChannel.bind("message-seen", function(data) {
            if (data.receiverId == '<?php echo e($recipient->id ?? ""); ?>' && data.senderId == '<?php echo e(auth()->user()->id); ?>') {

                if (data.status == 1) {
                    console.log(data.status);
                    $(".sentMessage").find(".fa-check-double").removeClass("fa-check-double").addClass("fa-check-double seen");
                }
            }


        });
        var channel = pusher.subscribe(recipientChannel);


        function updateTickmark(status) {
            if (status == "sent") {
                return '<i class="fas fa-check"></i>';
            } else if (status == "delivered") {
                return '<i class="fas fa-check-double"></i>';
            } else {
                return '<i class="fas fa-check-double seen" style="background-color: lightblue;"></i>';
            }
        }

        function changeread(status) {

            if (status == "delivered") {
                // Step 1: Select the <i> element with the class 'fas fa-check' inside the '.sentMessage' div
                var checkIcon = document.querySelector('.sentMessage .fas.fa-check');

                // Step 2: Check if the element exists
                if (checkIcon) {
                    // Step 3: Remove the existing classes
                    checkIcon.classList.remove('fa-check');

                    // Step 4: Add the new class
                    checkIcon.classList.add('fa-check-double');
                } else {
                    console.log("Element not found");
                }
            }

        }
        channel.bind('private-message', function(data) {
            let recipientUserId = data.recipientUserId; // Recipient user ID received from Pusher event
            let senderId = data.senderId; // Recipient user ID received from Pusher event
            let recipientId = '<?php echo e($recipient->id ?? ""); ?>'; // Authenticated user's ID

            let status = data.status === 0 ? "delivered" : "read";
            // Check if the recipient user ID matches the authenticated user's ID
            if (senderId == recipientId) {

                let tickMark = updateTickmark(status);

                let tickIcon = '<i class="fas fa-check-double"></i>';
                let tickStyle = status === "read" ? 'style="background-color: lightblue;"' : '';



                let receiverMessage = `
                    <div class="d-flex flex-row p-3">
                    <img src="https://img.icons8.com/color/48/000000/circled-user-female-skin-type-7.png" width="30" height="30">
                        <div class="chat ml-2 p-3">${data.message}</div>
                    </div>`;
                $("#chat_area").append(receiverMessage);


            }

            var chatId = senderId;
            var unreadCount = $('.unread-count[data-chat="' + chatId + '"]');
            if (unreadCount.length) {
                unreadCount.text(parseInt(unreadCount.text()) + 1);
            } else {
                var chatList = $('#chat-lists');
                var unreadSpan = '<span class="text-xs text-red-500 unread-count" data-chat="' + chatId + '">1</span>';
                chatList.find('a[href$="' + chatId + '"]').append(unreadSpan);
            }
        });

        $('#send-message').click(function() {
            var message = $('#message-input').val();
            $.ajax({
                method: 'POST',
                url: '<?php echo e(route("send.message", !empty($recipient)?$recipient->id:"")); ?>',
                data: {
                    '_token': '<?php echo e(csrf_token()); ?>',
                    'message': message
                },
                success: function(result) {
                    var chatId = '<?php echo e($recipient->id ?? ""); ?>';
                    if (chatId) {
                        let send = `
                            <div class="d-flex flex-row p-3">
                                <div class="bg-white mr-2 p-3 sentMessage"><span class="text-muted sendChat">${message}</span>${updateTickmark("sent")}</div>
                                <img src="https://img.icons8.com/color/48/000000/circled-user-male-skin-type-7.png" width="30" height="30">
                            </div>`;
                        $("#chat_area").append(send);
                        changeread("delivered");
                        getUserStatus(chatId)
                    }
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
            $('#message-input').val('');
        });

        $(document).ready(function() {

            markMessagesAsRead();

            function markMessagesAsRead(chatId) {
                var chatId = '<?php echo e($recipient->id ?? ""); ?>';
                if (chatId) {
                    $.ajax({
                        method: 'POST',
                        url: '<?php echo e(route("mark.messages.read")); ?>',
                        data: {
                            '_token': '<?php echo e(csrf_token()); ?>',
                            'chat_id': chatId
                        },
                        success: function(result) {
                            console.log('Messages marked as read');
                            $('.unread-count[data-chat="' + chatId + '"]').remove();
                            // changeread("read")


                        },
                        error: function(xhr, status, error) {
                            console.error(error);
                        }
                    });
                }
            }

            $(document).on('click', '#chat_area', function() {
                var chatId = '<?php echo e($recipient->id ?? ""); ?>';
                // $(".sentMessage .fa-check-double").css("background-color", "blue");
                markMessagesAsRead(chatId);
            });
        });
    </script>


</body>

</html><?php /**PATH D:\xampp812\htdocs\reattime-chat-app\resources\views/chat.blade.php ENDPATH**/ ?>